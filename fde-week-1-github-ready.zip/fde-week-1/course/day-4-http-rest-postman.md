# Day 4 — HTTP, REST and Postman

## Goal

Become comfortable inspecting and debugging unfamiliar APIs.

## Study

- https://developer.mozilla.org/en-US/docs/Web/HTTP
- https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status
- https://learning.postman.com/docs/getting-started/quick-start/

## Know these HTTP methods

```text
GET
POST
PUT
PATCH
DELETE
```

## Know these status codes

```text
200 OK
201 Created
204 No Content
400 Bad Request
401 Unauthorized
403 Forbidden
404 Not Found
409 Conflict
429 Too Many Requests
500 Server Error
502 Bad Gateway
503 Service Unavailable
```

## Postman exercise

Create a collection named:

`Acme Customer API`

Include:

- Get customers
- Get customer
- Create customer
- Update customer
- Delete customer

For every request inspect:

- URL
- Method
- Headers
- Body
- Status
- Response

## Debugging exercise

For each response below, explain likely causes and next steps:

- 401
- 403
- 404
- 429
- 500
- 503

## Deliverable

Export your Postman collection to:

`postman/acme-customer-api.json`
