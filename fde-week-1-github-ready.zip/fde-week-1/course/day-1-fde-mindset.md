# Day 1 — FDE Mindset and Customer Discovery

## Goal

Learn how an FDE approaches an ambiguous customer problem.

## Study

Read:

- https://openai.com/careers/forward-deployed-engineer-%28fde%29-sf-san-francisco/

Understand:

- Customer discovery
- Technical scoping
- System design
- Prototyping
- Production deployment
- Customer collaboration
- Measuring outcomes

## Mental model

```text
Customer Problem
      ↓
Discovery
      ↓
Workflow Understanding
      ↓
Technical Requirements
      ↓
Solution Design
      ↓
Prototype
      ↓
Integration
      ↓
Production
      ↓
Measure Impact
      ↓
Iterate
```

## Customer scenario

Acme Corporation has 500+ customers. Its operations team manually collects customer information, orders, revenue and support tickets every morning and creates a report. It takes 4–5 hours.

## Exercise

Create `docs/customer-discovery.md`.

Answer:

1. What is the business problem?
2. Who experiences it?
3. What is the current workflow?
4. Which systems might be involved?
5. What data is required?
6. How could the data be accessed?
7. What should be automated?
8. What could fail?
9. What security concerns exist?
10. What does success look like?

## Success criteria example

- Reporting time reduced from 5 hours to under 30 minutes.
- Data accuracy above 99%.
- Daily report generated automatically.

## Deliverable

`docs/customer-discovery.md`
