# Day 7 — End-to-End Data Integration

## Goal

Combine the week's learning into a working FDE-style integration.

## Target architecture

```text
External API
     |
     v
Python Connector
     |
     v
Validation
     |
     v
Transformation
     |
     v
PostgreSQL
     |
     v
FastAPI
```

## Concepts

Study and implement:

### Data mapping

External:

`company_name`

Internal:

`name`

### Normalization

Different source values should map to a consistent internal representation.

### Pagination

Handle APIs that return:

`page=1`, `page=2`, `page=3`, etc.

### Retry

Handle transient failures such as 503.

### Duplicate data

Do not blindly insert duplicate customer records.

### Partial failure

One bad customer record should not necessarily destroy an entire sync.

## Build

Create:

`POST /sync`

Expected flow:

```text
POST /sync
   ↓
Retrieve CRM data
   ↓
Validate
   ↓
Transform
   ↓
Create/update PostgreSQL records
   ↓
Return sync summary
```

Example response:

```json
{
  "status": "success",
  "customers_processed": 500,
  "customers_created": 470,
  "customers_updated": 30,
  "errors": 0
}
```

## Failure exercises

Test:

1. CRM returns 429.
2. CRM returns 503.
3. One customer has invalid data.
4. Duplicate customer arrives.
5. CRM is unavailable.
6. Customer has 100,000 records.

## Final deliverables

- Working `/sync`
- Connector
- Validation
- Transformation
- Database persistence
- Error handling
- README update
