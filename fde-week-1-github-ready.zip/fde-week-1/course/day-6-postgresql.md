# Day 6 — PostgreSQL

## Goal

Replace in-memory data with a relational database.

## Study

Read:

- https://www.postgresql.org/docs/current/tutorial.html

Focus on:

- Tables
- Primary keys
- Foreign keys
- INSERT
- SELECT
- WHERE
- ORDER BY
- GROUP BY
- JOIN
- COUNT
- SUM
- UPDATE
- DELETE
- Transactions

## Database

Create:

```text
customers
orders
tickets
activities
```

Relationships:

```text
Customer
  |
  +-- Orders
  |
  +-- Tickets
  |
  +-- Activities
```

## Required queries

1. Get all customers.
2. Get orders for one customer.
3. Calculate total revenue.
4. Calculate revenue per customer.
5. Find customers with more than 5 tickets.
6. Find open high-priority tickets.
7. Find customers with no recent orders.

## FDE exercise

For every SQL query, write its business meaning.

Example:

```text
SUM(order.amount)

Business meaning:
Total customer revenue.
```

## Deliverables

- `database/schema.sql`
- `database/seed.sql`
- `database/queries.sql`
