# Day 5 — FastAPI

## Goal

Build the backend API for the project.

## Study

- https://fastapi.tiangolo.com/tutorial/
- https://fastapi.tiangolo.com/tutorial/first-steps/
- https://fastapi.tiangolo.com/tutorial/sql-databases/

Focus on:

- Application setup
- Routes
- Path parameters
- Query parameters
- Request bodies
- Pydantic models
- Response models
- Status codes
- Error handling
- Swagger/OpenAPI

## Build

Create:

```text
GET    /customers
GET    /customers/{id}
POST   /customers
PUT    /customers/{id}
DELETE /customers/{id}
```

Initially use in-memory data.

## API design principle

Prefer:

`GET /customers`

over:

`GET /getAllCustomers`

Prefer:

`POST /customers`

over:

`POST /createCustomer`

The HTTP method already communicates the operation.

## Testing

Use:

- Swagger UI
- Postman

## Deliverable

Working CRUD API with API documentation.
