# Day 3 — Python for FDE Integrations

## Goal

Use Python to retrieve, validate, transform and save external data.

## Study

Read:

- https://docs.python.org/3/tutorial/

Focus on:

- Data structures
- Functions
- Modules
- Errors and exceptions
- File I/O
- JSON
- Virtual environments

## Integration concepts

You should understand:

- HTTP request
- JSON response
- Headers
- Query parameters
- Status codes
- Error handling

## Exercise

Build a Python connector with this flow:

```text
External API
    ↓
requests
    ↓
JSON
    ↓
Validation
    ↓
Transformation
    ↓
Normalized JSON
```

External example:

```json
{
  "customer_id": 101,
  "company_name": "Acme",
  "email_address": "ops@acme.example",
  "createdDate": "2026-01-10"
}
```

Internal format:

```json
{
  "id": 101,
  "name": "Acme",
  "email": "ops@acme.example",
  "created_at": "2026-01-10"
}
```

## FDE exercise

Write the transformation and explain why the internal model should be independent of the customer's API field names.

## Deliverable

Create a working connector under:

`backend/app/connectors/`
