# Week 1 Overview

## Objective

Turn an ambiguous customer problem into a working API + database + integration.

## Final project

Acme Corporation manually combines CRM, database, support and CSV data every morning. The process takes 4–5 hours.

Build a service that automates the data collection and exposes normalized customer data through an API.

## Final architecture

```text
CRM API
   |
   v
Python Connector
   |
   v
Validation / Transformation
   |
   v
PostgreSQL
   |
   v
FastAPI
   |
   v
Client
```

## Core FDE skills

- Customer discovery
- Requirements gathering
- System design
- API integration
- Data mapping
- Debugging
- Failure handling
- Business-to-technical translation
- Documentation
