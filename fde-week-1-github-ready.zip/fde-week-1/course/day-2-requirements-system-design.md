# Day 2 — Requirements and System Design

## Goal

Turn the customer problem into a technical solution.

## Study

Read:

- https://github.com/donnemartin/system-design-primer

Focus on:

- Client/server
- APIs
- Databases
- Data flow
- Scalability
- Availability
- Caching
- Architecture components

## Requirements concepts

### Functional requirement

What the system must do.

Example:
> The system must retrieve customers from the CRM.

### Non-functional requirement

How the system should behave.

Example:
> The API should normally respond within 500 ms.

### Constraint

A restriction on the solution.

Example:
> Customer data cannot be exposed publicly.

### Acceptance criterion

A measurable condition proving a feature works.

## Exercise

Create `docs/requirements.md`.

Define at least:

- 5 functional requirements
- 5 non-functional requirements
- 5 acceptance criteria
- technical assumptions
- constraints

## Architecture

Create `docs/architecture.md` and `docs/architecture.mmd`.

Target:

```text
CRM API
   |
   v
Integration Service
   |
   v
Validation
   |
   v
PostgreSQL
   |
   v
FastAPI
   |
   v
Client
```

For every component, explain why it exists.

## Deliverables

- `docs/requirements.md`
- `docs/architecture.md`
- `docs/architecture.mmd`
