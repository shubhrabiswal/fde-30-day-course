# Day 5 exercise:
# Implement customer CRUD endpoints here.
