import requests


class CRMConnector:
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def get_customers(self):
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = requests.get(
            f"{self.base_url}/customers",
            headers=headers,
            timeout=30,
        )
        response.raise_for_status()
        return response.json()
