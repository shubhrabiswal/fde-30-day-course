# Customer Discovery — Acme Corporation

## Status

Starter template. Complete this on Day 1.

## Business problem

[Your answer]

## Users / stakeholders

[Your answer]

## Current workflow

[Your answer]

## Systems involved

[Your answer]

## Data required

[Your answer]

## Integration questions

[Your answer]

## Security questions

[Your answer]

## Failure scenarios

[Your answer]

## Success metrics

[Your answer]
