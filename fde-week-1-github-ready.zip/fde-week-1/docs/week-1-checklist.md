# Week 1 Checklist

## Day 1
- [ ] Read FDE role material
- [ ] Complete customer discovery
- [ ] Define success metrics

## Day 2
- [ ] Study system design basics
- [ ] Write requirements
- [ ] Draw architecture

## Day 3
- [ ] Review Python integration concepts
- [ ] Build API connector
- [ ] Transform external JSON

## Day 4
- [ ] Study HTTP
- [ ] Study status codes
- [ ] Create Postman collection
- [ ] Practice API debugging

## Day 5
- [ ] Build FastAPI project
- [ ] Implement CRUD
- [ ] Test with Swagger
- [ ] Test with Postman

## Day 6
- [ ] Create PostgreSQL schema
- [ ] Insert seed data
- [ ] Write business queries
- [ ] Understand relationships

## Day 7
- [ ] Build sync endpoint
- [ ] Connect external API
- [ ] Validate data
- [ ] Transform data
- [ ] Persist data
- [ ] Handle failures
- [ ] Document the solution

## Final test

Given an unfamiliar customer API, can you:

- [ ] Understand authentication?
- [ ] Identify endpoints?
- [ ] Test requests?
- [ ] Map fields?
- [ ] Build a connector?
- [ ] Handle pagination?
- [ ] Handle retries?
- [ ] Avoid duplicates?
- [ ] Persist normalized data?
- [ ] Expose the data through your API?
- [ ] Explain the business value?
