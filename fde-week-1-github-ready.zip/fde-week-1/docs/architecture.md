# Architecture

## Context

Acme Corporation needs to consolidate customer data from external systems.

## Components

### External CRM

Provides customer information.

### Integration Service

Retrieves and transforms external data.

### PostgreSQL

Stores normalized internal data.

### FastAPI

Exposes application APIs.

## Data flow

```text
CRM API
   |
   v
Connector
   |
   v
Validation
   |
   v
Transformation
   |
   v
PostgreSQL
   |
   v
FastAPI
   |
   v
Client
```

## Design decisions

Complete during Day 2.

## Risks

Complete during Day 2.

## Future improvements

Complete during Day 7.
