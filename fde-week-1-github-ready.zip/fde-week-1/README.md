# Forward Deployed Engineer — Week 1

## Customer Data Integration Service

This repository is the Week 1 project for a 30-day Forward Deployed Engineer course.

### Goal

Build a customer data integration service that can:

- Connect to external customer systems
- Retrieve customer/order/support data
- Validate and transform external data
- Store normalized data in PostgreSQL
- Expose the data through a FastAPI backend
- Handle integration failures
- Document the solution from a customer/FDE perspective

## Architecture

```text
                 Customer Systems

          +----------------------+
          |       CRM API        |
          +----------+-----------+
                     |
                     v
             +---------------+
             | Python        |
             | Connector     |
             +-------+-------+
                     |
                     v
             +---------------+
             | Validation &  |
             | Transformation|
             +-------+-------+
                     |
                     v
             +---------------+
             | PostgreSQL    |
             +-------+-------+
                     |
                     v
             +---------------+
             | FastAPI       |
             +-------+-------+
                     |
                     v
                  Client
```

## Week 1 schedule

| Day | Focus | Main deliverable |
|---|---|---|
| 1 | FDE mindset + customer discovery | `docs/customer-discovery.md` |
| 2 | Requirements + system design | `docs/requirements.md`, architecture |
| 3 | Python for integrations | API connector |
| 4 | HTTP + REST + Postman | Postman collection |
| 5 | FastAPI | CRUD API |
| 6 | PostgreSQL | Schema + SQL queries |
| 7 | Integration | End-to-end sync |

## Study resources

- FDE role: https://openai.com/careers/forward-deployed-engineer-%28fde%29-sf-san-francisco/
- System Design Primer: https://github.com/donnemartin/system-design-primer
- Python: https://docs.python.org/3/tutorial/
- MDN HTTP: https://developer.mozilla.org/en-US/docs/Web/HTTP
- MDN Status Codes: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status
- Postman: https://learning.postman.com/docs/getting-started/quick-start/
- FastAPI: https://fastapi.tiangolo.com/tutorial/
- FastAPI SQL databases: https://fastapi.tiangolo.com/tutorial/sql-databases/
- PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

## Suggested study/build ratio

Spend approximately:

- 30% studying
- 70% building

Do not just watch tutorials. Every day must produce a working artifact.

## Final Week 1 API

Target endpoints:

```text
GET    /customers
GET    /customers/{id}
POST   /customers
PUT    /customers/{id}
DELETE /customers/{id}

GET    /customers/{id}/orders
GET    /customers/{id}/tickets

GET    /analytics/revenue
GET    /analytics/tickets

POST   /sync
```

## Final Week 1 success test

Given an unfamiliar CRM API, you should be able to:

1. Read its API documentation
2. Understand authentication
3. Test endpoints
4. Map external data to your internal model
5. Build a connector
6. Validate and transform data
7. Persist it in PostgreSQL
8. Expose it through FastAPI
9. Handle common failures
10. Explain the architecture and business value
