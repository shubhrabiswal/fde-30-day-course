# Day 18 — Customer Investigation Workflow

    ## Objective
    Learn multi-source investigation and evidence-backed answers.

    ## Study links
    - https://platform.openai.com/docs/guides
- https://platform.openai.com/docs/guides/evals

    ## Hands-on
    Implement: 'Why did Acme's orders fall?' by combining database metrics, tickets and documents.

    ## FDE principle
    A customer solution is not just an AI demo. It must know what data it can access, what actions it can take, how it can fail, and how the customer can verify its output.

    ## Required artifacts
    - Implementation
    - Tests
    - Example inputs/outputs
    - Failure cases
    - Short customer-facing explanation

    ## Definition of done
    - [ ] Happy path works.
    - [ ] At least three failure/edge cases are tested.
    - [ ] Data access is controlled.
    - [ ] Output can be explained with evidence.
