# Day 15 — Document Processing

## Objective
Learn extraction, chunking, metadata and document lifecycle.

## Study links
- https://platform.openai.com/docs/guides/embeddings

## Hands-on
Support PDF/DOCX/Markdown/CSV ingestion. Store source metadata and searchable chunks.

## FDE principle
A customer solution is not just an AI demo. It must know what data it can access, what actions it can take, how it can fail, and how the customer can verify its output.

## Required artifacts
- Implementation
- Tests
- Example inputs/outputs
- Failure cases
- Short customer-facing explanation

## Definition of done
- [ ] Happy path works.
- [ ] At least three failure/edge cases are tested.
- [ ] Data access is controlled.
- [ ] Output can be explained with evidence.
