# Day 17 — AI Agent

    ## Objective
    Learn agent state, tool selection, execution loops, guardrails and termination conditions.

    ## Study links
    - https://platform.openai.com/docs/guides/function-calling
- https://platform.openai.com/docs/guides

    ## Hands-on
    Build an agent that can answer a business question by choosing between database and document tools.

    ## FDE principle
    A customer solution is not just an AI demo. It must know what data it can access, what actions it can take, how it can fail, and how the customer can verify its output.

    ## Required artifacts
    - Implementation
    - Tests
    - Example inputs/outputs
    - Failure cases
    - Short customer-facing explanation

    ## Definition of done
    - [ ] Happy path works.
    - [ ] At least three failure/edge cases are tested.
    - [ ] Data access is controlled.
    - [ ] Output can be explained with evidence.
