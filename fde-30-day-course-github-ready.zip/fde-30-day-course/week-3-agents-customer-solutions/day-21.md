# Day 21 — Security + Data Boundaries

    ## Objective
    Learn authentication, authorization, secrets, tenant isolation, least privilege, PII handling and prompt/tool security.

    ## Study links
    - https://owasp.org/www-project-top-ten/
- https://owasp.org/www-project-api-security/
- https://docs.aws.amazon.com/IAM/latest/UserGuide/getting-started.html

    ## Hands-on
    Implement roles, tenant checks, secret management practices and tool permissions. Document your threat model.

    ## FDE principle
    A customer solution is not just an AI demo. It must know what data it can access, what actions it can take, how it can fail, and how the customer can verify its output.

    ## Required artifacts
    - Implementation
    - Tests
    - Example inputs/outputs
    - Failure cases
    - Short customer-facing explanation

    ## Definition of done
    - [ ] Happy path works.
    - [ ] At least three failure/edge cases are tested.
    - [ ] Data access is controlled.
    - [ ] Output can be explained with evidence.
