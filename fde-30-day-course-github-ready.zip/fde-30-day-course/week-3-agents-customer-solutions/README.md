# Week 3 — Agents + Customer Solutions

## Days 15–21

This week continues the same project.

## Milestone

**Customer investigation agent + configurable workflows**

Use the daily files in this folder in order.

Rule:

**Study 30% → Build 70% → Test → Document → Commit**
