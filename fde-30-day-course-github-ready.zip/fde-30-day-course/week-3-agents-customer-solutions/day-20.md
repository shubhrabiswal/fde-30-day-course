# Day 20 — Customer-Specific Configuration

## Objective
Learn tenant configuration, feature flags, customer-specific prompts, connectors and workflow configuration.

## Study links
- https://owasp.org/www-project-api-security/

## Hands-on
Make the application support Customer A and Customer B with different data sources and configuration without changing core code.

## FDE principle
A customer solution is not just an AI demo. It must know what data it can access, what actions it can take, how it can fail, and how the customer can verify its output.

## Required artifacts
- Implementation
- Tests
- Example inputs/outputs
- Failure cases
- Short customer-facing explanation

## Definition of done
- [ ] Happy path works.
- [ ] At least three failure/edge cases are tested.
- [ ] Data access is controlled.
- [ ] Output can be explained with evidence.
