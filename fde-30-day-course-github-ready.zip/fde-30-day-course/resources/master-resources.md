# Master Study Resources

Use official documentation first. Do not collect dozens of random tutorials.

## FDE / customer deployment

OpenAI FDE careers:
https://openai.com/careers/search/?q=FDE

OpenAI FDE role:
https://openai.com/careers/forward-deployed-engineer-%28fde%29-sf-san-francisco/

Forward Deployed Software Engineer:
https://openai.com/careers/forward-deployed-software-engineer-sf-san-francisco/

## System design

System Design Primer:
https://github.com/donnemartin/system-design-primer

## Python

Python tutorial:
https://docs.python.org/3/tutorial/

Python requests:
https://requests.readthedocs.io/en/latest/

## HTTP / APIs

MDN HTTP:
https://developer.mozilla.org/en-US/docs/Web/HTTP

MDN HTTP status:
https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status

Postman:
https://learning.postman.com/docs/getting-started/quick-start/

## FastAPI

FastAPI tutorial:
https://fastapi.tiangolo.com/tutorial/

FastAPI first steps:
https://fastapi.tiangolo.com/tutorial/first-steps/

FastAPI SQL databases:
https://fastapi.tiangolo.com/tutorial/sql-databases/

## PostgreSQL

PostgreSQL tutorial:
https://www.postgresql.org/docs/current/tutorial.html

PostgreSQL documentation:
https://www.postgresql.org/docs/current/

## Docker

Docker getting started:
https://docs.docker.com/get-started/

Docker hands-on lab:
https://docs.docker.com/guides/lab-container-getting-started/

Docker overview:
https://docs.docker.com/get-started/docker-overview

## GitHub / CI/CD

GitHub Actions quickstart:
https://docs.github.com/en/actions/get-started/quickstart

GitHub Git learning resources:
https://docs.github.com/en/get-started/start-your-journey/git-and-github-learning-resources

## AWS

EC2 getting started:
https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/EC2_GetStarted.html

RDS getting started:
https://docs.aws.amazon.com/AmazonRDS/latest/gettingstartedguide/setting-up.html

IAM getting started:
https://docs.aws.amazon.com/IAM/latest/UserGuide/getting-started.html

CloudWatch getting started:
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/GettingSetup.html

AWS getting started:
https://aws.amazon.com/getting-started/

## Angular

Angular documentation:
https://angular.dev/docs

Angular tutorials:
https://angular.dev/tutorials

Angular first app:
https://angular.dev/tutorials/first-app

Angular essentials:
https://angular.dev/essentials

## AI / LLM

OpenAI API documentation:
https://platform.openai.com/docs

OpenAI API quickstart:
https://platform.openai.com/docs/quickstart

OpenAI guides:
https://platform.openai.com/docs/guides

OpenAI function calling/tools:
https://platform.openai.com/docs/guides/function-calling

OpenAI embeddings:
https://platform.openai.com/docs/guides/embeddings

OpenAI evaluation guidance:
https://platform.openai.com/docs/guides/evals

## Observability

OpenTelemetry:
https://opentelemetry.io/docs/

AWS CloudWatch:
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/GettingSetup.html

## Testing

pytest:
https://docs.pytest.org/en/stable/

Playwright:
https://playwright.dev/docs/intro

## Security

OWASP Top 10:
https://owasp.org/www-project-top-ten/

OWASP API Security:
https://owasp.org/www-project-api-security/
