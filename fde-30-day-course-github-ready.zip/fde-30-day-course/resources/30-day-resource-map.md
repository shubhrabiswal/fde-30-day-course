# 30-Day Resource Map

## Days 1–7
FDE + system design + Python + HTTP + FastAPI + PostgreSQL + integration.

## Days 8–11
Docker + AWS + deployment + GitHub Actions.

## Days 12–14
LLM fundamentals + prompting + embeddings/RAG.

## Days 15–18
Documents + tools + agents + investigations.

## Days 19–21
Automation + customer configuration + security.

## Days 22–24
Angular + AI UX + production quality.

## Days 25–27
Monitoring + performance/cost + testing/evals.

## Days 28–30
Handoff + FDE simulation + final capstone.

For the exact links, use `master-resources.md` and each day's lesson file.
