# FDE Interview Preparation

## 1. Customer discovery questions

Practice asking:

- What workflow are you trying to improve?
- Who performs it today?
- How often does it happen?
- What systems are involved?
- What data is authoritative?
- What are the failure modes?
- What constraints exist?
- What does success mean?
- How will adoption be measured?

## 2. System design questions

Practice:

- Design a customer data integration platform.
- Design a multi-tenant AI assistant.
- Design an event-driven integration.
- Design a document search system.
- Design an incident investigation system.

## 3. Debugging questions

Practice:

- API returns 401.
- API returns 429.
- Database becomes slow.
- Webhook stops.
- Customer data is duplicated.
- LLM starts hallucinating.
- Retrieval returns irrelevant documents.
- Production latency doubles.

## 4. AI questions

Know:

- RAG
- embeddings
- chunking
- tool calling
- agent loops
- prompt injection
- hallucination
- evaluation
- grounding
- latency
- cost

## 5. Behavioral questions

Prepare stories for:

- Ambiguous requirements
- Difficult customer/stakeholder
- Production incident
- Fast prototype
- Technical tradeoff
- Scope reduction
- Failed approach
- Learning from field feedback
- Driving adoption

## 6. FDE answer structure

Use:

Situation → Customer problem → Constraints → Technical approach → Tradeoff → Implementation → Result → What you learned
