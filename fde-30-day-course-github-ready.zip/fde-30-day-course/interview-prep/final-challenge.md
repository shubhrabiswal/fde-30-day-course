# Final FDE Challenge

## Scenario

A customer says:

> Our operations team spends six hours every day preparing reports from CRM data, support tickets, spreadsheets and internal documents. We want an AI assistant that can explain what changed and why.

## Time box

4 hours.

## Required output

### 1. Discovery

List your questions.

### 2. Requirements

Functional + non-functional.

### 3. Architecture

Draw the system.

### 4. Prototype

Build the smallest working vertical slice.

### 5. AI

Show one grounded question-answering workflow.

### 6. Deployment

Deploy or provide a reproducible local production-like environment.

### 7. Evaluation

Define 10 tests.

### 8. Demo

Explain the solution in 10 minutes.

### 9. Tradeoffs

Explain what you intentionally did not build.

### 10. Next steps

Give a realistic 2–4 week roadmap.
