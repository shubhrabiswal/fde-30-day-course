# Week 2 — Cloud + AI

## Days 8–14

This week continues the same project.

## Milestone

**Deployed AI-enabled backend + RAG prototype**

Use the daily files in this folder in order.

Rule:

**Study 30% → Build 70% → Test → Document → Commit**
