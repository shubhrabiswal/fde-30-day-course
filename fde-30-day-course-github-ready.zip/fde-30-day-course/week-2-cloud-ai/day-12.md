# Day 12 — LLM Fundamentals

    ## Objective
    Learn tokens, context, prompts, system instructions, structured outputs and model API calls.

    ## Study links
    - https://platform.openai.com/docs/quickstart
- https://platform.openai.com/docs/guides

    ## Lesson
    Keep the FDE goal visible: build the smallest useful version first, then make it reliable enough for a real customer.

    ## Hands-on
    Create an LLM endpoint that accepts a customer question and returns a structured business analysis.

    ## Required thinking
    - What is the simplest version that proves the idea?
    - What would break in a real customer's environment?
    - What should be configurable?
    - What should be logged?
    - What should be measured?

    ## Deliverable
    Commit the implementation and update the project README.

    ## Definition of done
    - [ ] Feature works locally.
    - [ ] Feature is tested.
    - [ ] Failure behavior is documented.
    - [ ] Customer value is stated in one paragraph.
