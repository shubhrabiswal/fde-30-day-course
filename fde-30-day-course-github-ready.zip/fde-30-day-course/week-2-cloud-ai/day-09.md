# Day 9 — AWS Fundamentals

    ## Objective
    Learn the small AWS subset needed for FDE work: IAM, EC2, networking, S3 and RDS.

    ## Study links
    - https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/EC2_GetStarted.html
- https://docs.aws.amazon.com/IAM/latest/UserGuide/getting-started.html
- https://docs.aws.amazon.com/AmazonRDS/latest/gettingstartedguide/setting-up.html

    ## Lesson
    Keep the FDE goal visible: build the smallest useful version first, then make it reliable enough for a real customer.

    ## Hands-on
    Create a simple AWS architecture for the project and document security boundaries and cost considerations.

    ## Required thinking
    - What is the simplest version that proves the idea?
    - What would break in a real customer's environment?
    - What should be configurable?
    - What should be logged?
    - What should be measured?

    ## Deliverable
    Commit the implementation and update the project README.

    ## Definition of done
    - [ ] Feature works locally.
    - [ ] Feature is tested.
    - [ ] Failure behavior is documented.
    - [ ] Customer value is stated in one paragraph.
