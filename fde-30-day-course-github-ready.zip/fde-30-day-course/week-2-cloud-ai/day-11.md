# Day 11 — CI/CD

## Objective
Learn GitHub Actions, automated tests, builds, secrets and deployment workflows.

## Study links
- https://docs.github.com/en/actions/get-started/quickstart

## Lesson
Keep the FDE goal visible: build the smallest useful version first, then make it reliable enough for a real customer.

## Hands-on
Create a workflow that runs tests on push and builds the application. Add deployment as a second stage.

## Required thinking
- What is the simplest version that proves the idea?
- What would break in a real customer's environment?
- What should be configurable?
- What should be logged?
- What should be measured?

## Deliverable
Commit the implementation and update the project README.

## Definition of done
- [ ] Feature works locally.
- [ ] Feature is tested.
- [ ] Failure behavior is documented.
- [ ] Customer value is stated in one paragraph.
