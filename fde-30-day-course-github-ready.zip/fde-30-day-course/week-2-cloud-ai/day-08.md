# Day 8 — Docker Fundamentals

    ## Objective
    Understand images, containers, Dockerfiles, volumes, networks and Compose.

    ## Study links
    - https://docs.docker.com/get-started/
- https://docs.docker.com/guides/lab-container-getting-started/

    ## Lesson
    Keep the FDE goal visible: build the smallest useful version first, then make it reliable enough for a real customer.

    ## Hands-on
    Containerize FastAPI and PostgreSQL. Run the complete backend with one docker compose command.

    ## Required thinking
    - What is the simplest version that proves the idea?
    - What would break in a real customer's environment?
    - What should be configurable?
    - What should be logged?
    - What should be measured?

    ## Deliverable
    Commit the implementation and update the project README.

    ## Definition of done
    - [ ] Feature works locally.
    - [ ] Feature is tested.
    - [ ] Failure behavior is documented.
    - [ ] Customer value is stated in one paragraph.
