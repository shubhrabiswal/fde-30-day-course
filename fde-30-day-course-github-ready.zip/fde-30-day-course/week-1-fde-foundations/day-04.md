# Day 4 — HTTP + REST + Postman

    ## Objective
    Learn methods, headers, body, path/query parameters, authentication and important status codes.

    ## Study links
    - https://developer.mozilla.org/en-US/docs/Web/HTTP
- https://learning.postman.com/docs/getting-started/quick-start/

    ## Lesson
    The FDE principle for this day is:

    > Translate customer needs into a working technical artifact.

    Study the linked material actively. Take notes only for concepts you can explain or use.

    ## Hands-on assignment
    Create a Postman collection and test GET/POST/PUT/PATCH/DELETE. Debug 401, 403, 404, 429, 500 and 503 scenarios.

    ## FDE questions
    - What business problem does this solve?
    - What assumption are you making?
    - What can fail?
    - How would you explain this to a customer?
    - What evidence would prove it works?

    ## Deliverable
    Create a commit containing the day's work.

    ## Definition of done
    - [ ] I can explain the concepts without notes.
    - [ ] The implementation runs locally.
    - [ ] I tested at least one failure case.
    - [ ] I documented what I built.
