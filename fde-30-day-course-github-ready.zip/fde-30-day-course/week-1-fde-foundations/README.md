# Week 1 — FDE Foundations

## Days 1–7

This week continues the same project.

## Milestone

**Customer Data Integration Service**

Use the daily files in this folder in order.

Rule:

**Study 30% → Build 70% → Test → Document → Commit**
