# Day 1 — FDE Mindset + Customer Discovery

## Objective
Read an FDE role description and learn discovery, technical scoping, system design, production rollout and measurable customer impact.

## Study links
- https://openai.com/careers/forward-deployed-engineer-%28fde%29-sf-san-francisco/

## Lesson
The FDE principle for this day is:

> Translate customer needs into a working technical artifact.

Study the linked material actively. Take notes only for concepts you can explain or use.

## Hands-on assignment
Write customer-discovery.md for Acme: problem, users, current workflow, systems, data, constraints, failure scenarios and three measurable success metrics.

## FDE questions
- What business problem does this solve?
- What assumption are you making?
- What can fail?
- How would you explain this to a customer?
- What evidence would prove it works?

## Deliverable
Create a commit containing the day's work.

## Definition of done
- [ ] I can explain the concepts without notes.
- [ ] The implementation runs locally.
- [ ] I tested at least one failure case.
- [ ] I documented what I built.
