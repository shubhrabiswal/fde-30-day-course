# Day 6 — PostgreSQL

## Objective
Learn tables, keys, joins, aggregates, indexes, transactions and relational modeling.

## Study links
- https://www.postgresql.org/docs/current/tutorial.html

## Lesson
The FDE principle for this day is:

> Translate customer needs into a working technical artifact.

Study the linked material actively. Take notes only for concepts you can explain or use.

## Hands-on assignment
Create customers, orders, tickets and activities. Seed data and write seven business queries.

## FDE questions
- What business problem does this solve?
- What assumption are you making?
- What can fail?
- How would you explain this to a customer?
- What evidence would prove it works?

## Deliverable
Create a commit containing the day's work.

## Definition of done
- [ ] I can explain the concepts without notes.
- [ ] The implementation runs locally.
- [ ] I tested at least one failure case.
- [ ] I documented what I built.
