# Day 3 — Python for Integrations

    ## Objective
    Review Python data structures, functions, modules, JSON, exceptions, files, virtual environments and HTTP requests.

    ## Study links
    - https://docs.python.org/3/tutorial/
- https://requests.readthedocs.io/en/latest/

    ## Lesson
    The FDE principle for this day is:

    > Translate customer needs into a working technical artifact.

    Study the linked material actively. Take notes only for concepts you can explain or use.

    ## Hands-on assignment
    Build a Python connector that calls an API, validates the response, maps external fields to an internal customer model and writes normalized JSON.

    ## FDE questions
    - What business problem does this solve?
    - What assumption are you making?
    - What can fail?
    - How would you explain this to a customer?
    - What evidence would prove it works?

    ## Deliverable
    Create a commit containing the day's work.

    ## Definition of done
    - [ ] I can explain the concepts without notes.
    - [ ] The implementation runs locally.
    - [ ] I tested at least one failure case.
    - [ ] I documented what I built.
