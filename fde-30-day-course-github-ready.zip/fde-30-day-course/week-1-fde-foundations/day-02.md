# Day 2 — Requirements + System Design

## Objective
Learn functional/non-functional requirements, constraints, assumptions, acceptance criteria, architecture components and data flows.

## Study links
- https://github.com/donnemartin/system-design-primer

## Lesson
The FDE principle for this day is:

> Translate customer needs into a working technical artifact.

Study the linked material actively. Take notes only for concepts you can explain or use.

## Hands-on assignment
Create requirements.md, architecture.md and a Mermaid architecture diagram for the Acme integration platform.

## FDE questions
- What business problem does this solve?
- What assumption are you making?
- What can fail?
- How would you explain this to a customer?
- What evidence would prove it works?

## Deliverable
Create a commit containing the day's work.

## Definition of done
- [ ] I can explain the concepts without notes.
- [ ] The implementation runs locally.
- [ ] I tested at least one failure case.
- [ ] I documented what I built.
