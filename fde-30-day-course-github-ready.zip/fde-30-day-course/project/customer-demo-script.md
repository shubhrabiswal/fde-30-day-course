# Customer Demo Script

## 1. Problem

Explain the manual process and its cost.

## 2. Solution

Explain the platform in one minute.

## 3. Data integration

Show customer systems flowing into the normalized data layer.

## 4. Dashboard

Show KPIs and operational views.

## 5. AI question

Ask:

> Why did Acme's orders fall this month?

Show the reasoning result and evidence.

## 6. Knowledge question

Ask:

> What is our refund policy?

Show retrieved source evidence.

## 7. Investigation

Demonstrate the multi-source investigation workflow.

## 8. Automation

Show the daily operations report.

## 9. Reliability

Show logs, health checks and monitoring.

## 10. Security

Explain authentication, authorization and tenant isolation.

## 11. Impact

Show before/after metrics.

## 12. Next steps

Explain what you would build next and what you deliberately did not build.
