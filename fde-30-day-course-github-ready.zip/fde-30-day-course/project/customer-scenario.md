# Final Customer Scenario

## Customer

Acme Corporation

## Current environment

- CRM
- PostgreSQL
- Support-ticket system
- CSV/Excel operational reports
- Internal PDFs/DOCX/Markdown
- Application logs

## Current problem

Operations teams spend hours collecting information from different systems and investigating business issues manually.

## Desired outcome

One operational intelligence platform where authorized users can:

- View KPIs
- Ask business questions
- Investigate customer issues
- Search internal knowledge
- Receive automated daily insights
- Understand the evidence behind AI answers

## Success metrics

Initial targets:

- Reduce daily reporting effort by at least 80%.
- Answer common operational questions in under 60 seconds.
- Provide evidence for AI-generated business conclusions.
- Keep unauthorized customer data isolated.
- Maintain a documented production runbook.
