# Final Deliverables

## Product

- [ ] Angular dashboard
- [ ] FastAPI backend
- [ ] PostgreSQL
- [ ] Customer connectors
- [ ] Document ingestion
- [ ] RAG
- [ ] AI assistant
- [ ] Tool-calling agent
- [ ] Customer investigation workflow
- [ ] Automated report
- [ ] Customer configuration
- [ ] Authentication/authorization
- [ ] Monitoring
- [ ] Tests
- [ ] Deployment

## Documentation

- [ ] Customer discovery
- [ ] Requirements
- [ ] Architecture
- [ ] Data model
- [ ] API documentation
- [ ] Integration guide
- [ ] Security model
- [ ] Evaluation methodology
- [ ] Deployment guide
- [ ] Troubleshooting/runbook
- [ ] User guide
- [ ] Known limitations
- [ ] Future roadmap

## Demo

Your final demo should show:

1. Customer problem
2. Current workflow
3. Solution
4. Architecture
5. Data integration
6. Dashboard
7. Natural-language question
8. Investigation workflow
9. Evidence
10. Automated report
11. Monitoring
12. Security
13. Metrics
14. Limitations
15. Next steps
