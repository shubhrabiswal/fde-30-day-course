# Day 25 — Monitoring + Debugging

    ## Objective
    Learn structured logs, health checks, metrics, request tracing concepts and incident triage.

    ## Study links
    - https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/GettingSetup.html
- https://opentelemetry.io/docs/

    ## Hands-on
    Add health endpoint, structured logs, correlation/request IDs and basic CloudWatch monitoring.

    ## FDE questions
    - What customer outcome does this enable?
    - What would make a customer reject this?
    - What is the risk?
    - What metric proves success?
    - What should be reusable for the next customer?

    ## Definition of done
    - [ ] Working implementation.
    - [ ] Tests or validation evidence.
    - [ ] Documentation.
    - [ ] Customer-facing explanation.
