# Day 22 — Angular Customer Dashboard

    ## Objective
    Build the customer-facing operational dashboard. Use Angular because the portfolio should demonstrate full-stack delivery.

    ## Study links
    - https://angular.dev/docs
- https://angular.dev/tutorials
- https://angular.dev/essentials

    ## Hands-on
    Create Overview, Customers, Orders, Tickets, Data Sources and AI Assistant sections.

    ## FDE questions
    - What customer outcome does this enable?
    - What would make a customer reject this?
    - What is the risk?
    - What metric proves success?
    - What should be reusable for the next customer?

    ## Definition of done
    - [ ] Working implementation.
    - [ ] Tests or validation evidence.
    - [ ] Documentation.
    - [ ] Customer-facing explanation.
