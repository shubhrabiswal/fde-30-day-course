# Day 29 — FDE Simulation

## Objective
Practice a time-boxed customer engagement from discovery through working prototype.

## Study links
- https://openai.com/careers/forward-deployed-engineer-%28fde%29-sf-san-francisco/

## Hands-on
Given a new customer scenario, spend four hours on discovery, requirements, architecture, prototype, deployment and demo.

## FDE questions
- What customer outcome does this enable?
- What would make a customer reject this?
- What is the risk?
- What metric proves success?
- What should be reusable for the next customer?

## Definition of done
- [ ] Working implementation.
- [ ] Tests or validation evidence.
- [ ] Documentation.
- [ ] Customer-facing explanation.
