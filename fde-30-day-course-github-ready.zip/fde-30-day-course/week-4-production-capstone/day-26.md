# Day 26 — Performance + Cost

## Objective
Learn latency budgets, database query cost, API latency, LLM usage and infrastructure cost.

## Study links
- https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/cloudwatch-metrics-basic-detailed.html

## Hands-on
Measure API, database and LLM latency. Identify the top three cost/performance improvements.

## FDE questions
- What customer outcome does this enable?
- What would make a customer reject this?
- What is the risk?
- What metric proves success?
- What should be reusable for the next customer?

## Definition of done
- [ ] Working implementation.
- [ ] Tests or validation evidence.
- [ ] Documentation.
- [ ] Customer-facing explanation.
