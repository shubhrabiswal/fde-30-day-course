# Day 30 — Final Capstone + Customer Demo

    ## Objective
    Prove end-to-end FDE capability.

    ## Study links
    - https://openai.com/careers/forward-deployed-engineer-%28fde%29-sf-san-francisco/
- https://openai.com/careers/forward-deployed-software-engineer-sf-san-francisco/

    ## Hands-on
    Deliver the complete AI Operations Intelligence Platform, record/demo it, present architecture, explain tradeoffs, show metrics and document future work.

    ## FDE questions
    - What customer outcome does this enable?
    - What would make a customer reject this?
    - What is the risk?
    - What metric proves success?
    - What should be reusable for the next customer?

    ## Definition of done
    - [ ] Working implementation.
    - [ ] Tests or validation evidence.
    - [ ] Documentation.
    - [ ] Customer-facing explanation.
