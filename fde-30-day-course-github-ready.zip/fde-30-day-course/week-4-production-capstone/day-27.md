# Day 27 — Testing + AI Evaluation

    ## Objective
    Learn unit, integration, API and end-to-end tests plus evaluation datasets for AI behavior.

    ## Study links
    - https://docs.pytest.org/en/stable/
- https://playwright.dev/docs/intro
- https://platform.openai.com/docs/guides/evals

    ## Hands-on
    Create at least 20 backend/API tests and 20 AI evaluation cases covering correctness, refusal, grounding and tool selection.

    ## FDE questions
    - What customer outcome does this enable?
    - What would make a customer reject this?
    - What is the risk?
    - What metric proves success?
    - What should be reusable for the next customer?

    ## Definition of done
    - [ ] Working implementation.
    - [ ] Tests or validation evidence.
    - [ ] Documentation.
    - [ ] Customer-facing explanation.
