# Day 23 — AI Assistant UI

## Objective
Learn conversational UX, evidence display, loading/error states and action affordances.

## Study links
- https://angular.dev/docs

## Hands-on
Build a chat interface where questions return an answer plus evidence and source references.

## FDE questions
- What customer outcome does this enable?
- What would make a customer reject this?
- What is the risk?
- What metric proves success?
- What should be reusable for the next customer?

## Definition of done
- [ ] Working implementation.
- [ ] Tests or validation evidence.
- [ ] Documentation.
- [ ] Customer-facing explanation.
